//
//  cocoapods_bin_issue_11_import_PodB.h
//  cocoapods_bin_issue_11_import_PodB
//
//  Created by tripleCC on 9/19/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface cocoapods_bin_issue_11_import_PodB : NSObject

@end

NS_ASSUME_NONNULL_END
